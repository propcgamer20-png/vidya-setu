# VidyaSetu

A voice-first regional-language AI study assistant. Speak a doubt in Hindi or Marathi and get a spoken, step-by-step explanation back in that same language — plus an English translation shown side by side.

Also includes a PDF translation tool: upload a document and get it translated into your selected language.

## Why this exists

Most AI study tools default to English-first, text-first design. VidyaSetu is built the other way around: voice in, voice out, in the language a student actually thinks in — with support for code-switched sentences (e.g. an English technical term dropped into a Hindi or Marathi sentence).

## Tech stack

- **Model:** [GPT-OSS-120B](https://huggingface.co/openai/gpt-oss-120b) (OpenAI's open-weight model), served via [Groq](https://groq.com)'s free API tier
- **Voice:** Browser-native Web Speech API (`SpeechRecognition` for input, `speechSynthesis` for output)
- **PDF parsing:** [pdf.js](https://mozilla.github.io/pdf.js/) (client-side text extraction, no server upload)
- **Frontend:** Plain HTML/CSS/JS — no build step, no framework, no backend

Everything runs client-side in the browser. There is no server component; the only external calls are to Groq's API (for the AI reasoning/translation) and the browser's own OS-level speech services.

## Running it locally

Voice input requires a **secure context** — opening the file directly (`file://...`) will silently block microphone access in most browsers. Serve it locally instead:

```bash
# Option 1: Python
python3 -m http.server 8000
# then open http://localhost:8000/index.html

# Option 2: VS Code
# Install the "Live Server" extension (by Ritwick Dey),
# right-click index.html → "Open with Live Server"
```

## Getting a free API key

VidyaSetu runs on Groq's free tier for GPT-OSS-120B — no card required:

1. Go to [console.groq.com](https://console.groq.com) and sign in
2. Open **API Keys** in the left menu
3. Click **Create API Key**, copy it (shown once)
4. Paste it into the key field in the app — it's used only in your browser for that session, never stored or sent anywhere else

Free tier limits (subject to change — check `console.groq.com` for current numbers): 30 requests/min, 1,000 requests/day, 8,000 tokens/min, 200,000 tokens/day. The app shows your live remaining quota after each request where the browser is able to read it.

## Status

Working prototype: live voice doubt-solving in Hindi/Marathi with English translation, plus PDF upload-and-translate. Current scope covers two languages and general doubt-solving; board/curriculum-specific tuning and additional languages are natural next steps.

## License

MIT — see [LICENSE](LICENSE).
